﻿using System;

namespace First
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello World ");
            Console.ReadKey();
        }
    }
}
