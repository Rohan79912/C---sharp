﻿namespace FirstDesktopApplication
{
    partial class deletetbtn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.txtmname = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.rbfemale = new System.Windows.Forms.RadioButton();
            this.rbmale = new System.Windows.Forms.RadioButton();
            this.cmbqualification = new System.Windows.Forms.ComboBox();
            this.cmbcity = new System.Windows.Forms.ComboBox();
            this.cmbcountry = new System.Windows.Forms.ComboBox();
            this.cmbage = new System.Windows.Forms.ComboBox();
            this.cmbms = new System.Windows.Forms.ComboBox();
            this.txtmail = new System.Windows.Forms.TextBox();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.cbhindi = new System.Windows.Forms.CheckBox();
            this.cbenglish = new System.Windows.Forms.CheckBox();
            this.insertbtn = new System.Windows.Forms.Button();
            this.clearbtn = new System.Windows.Forms.Button();
            this.dtpdob = new System.Windows.Forms.DateTimePicker();
            this.rbother = new System.Windows.Forms.RadioButton();
            this.cburdu = new System.Windows.Forms.CheckBox();
            this.updatebtn = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.viewbtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cmbid = new System.Windows.Forms.ComboBox();
            this.studentBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.eMPDataSet1 = new FirstDesktopApplication.EMPDataSet1();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.eMPDataSet = new FirstDesktopApplication.EMPDataSet();
            this.label16 = new System.Windows.Forms.Label();
            this.studentTableAdapter = new FirstDesktopApplication.EMPDataSetTableAdapters.studentTableAdapter();
            this.studentTableAdapter1 = new FirstDesktopApplication.EMPDataSet1TableAdapters.studentTableAdapter();
            this.ferrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eMPDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eMPDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ferrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(163, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "REGISTRATION FORM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "FULL NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 113);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "FATHER NAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 153);
            this.label4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "MOTHER NAME";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 197);
            this.label5.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "DATE OF BIRTH";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 233);
            this.label6.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "ADDRESS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(16, 273);
            this.label7.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "QUALIFICATION";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(16, 351);
            this.label8.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "COUNTRY";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(16, 311);
            this.label9.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = "CITY";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(16, 394);
            this.label10.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 25);
            this.label10.TabIndex = 9;
            this.label10.Text = "GENDER";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(16, 438);
            this.label11.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 25);
            this.label11.TabIndex = 10;
            this.label11.Text = "E-MAIL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(16, 473);
            this.label12.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 25);
            this.label12.TabIndex = 11;
            this.label12.Text = "MOBILE";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(16, 514);
            this.label13.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 25);
            this.label13.TabIndex = 12;
            this.label13.Text = "AGE";
            // 
            // txtname
            // 
            this.txtname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(277, 71);
            this.txtname.Margin = new System.Windows.Forms.Padding(1);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(269, 30);
            this.txtname.TabIndex = 14;
            // 
            // txtfname
            // 
            this.txtfname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfname.Location = new System.Drawing.Point(277, 111);
            this.txtfname.Margin = new System.Windows.Forms.Padding(1);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(271, 30);
            this.txtfname.TabIndex = 15;
            // 
            // txtmname
            // 
            this.txtmname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmname.Location = new System.Drawing.Point(277, 149);
            this.txtmname.Margin = new System.Windows.Forms.Padding(1);
            this.txtmname.Name = "txtmname";
            this.txtmname.Size = new System.Drawing.Size(271, 30);
            this.txtmname.TabIndex = 16;
            // 
            // txtaddress
            // 
            this.txtaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress.Location = new System.Drawing.Point(277, 230);
            this.txtaddress.Margin = new System.Windows.Forms.Padding(1);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(271, 30);
            this.txtaddress.TabIndex = 17;
            // 
            // rbfemale
            // 
            this.rbfemale.AutoSize = true;
            this.rbfemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbfemale.Location = new System.Drawing.Point(277, 391);
            this.rbfemale.Margin = new System.Windows.Forms.Padding(1);
            this.rbfemale.Name = "rbfemale";
            this.rbfemale.Size = new System.Drawing.Size(113, 29);
            this.rbfemale.TabIndex = 18;
            this.rbfemale.TabStop = true;
            this.rbfemale.Text = "FEMALE";
            this.rbfemale.UseVisualStyleBackColor = true;
            // 
            // rbmale
            // 
            this.rbmale.AutoSize = true;
            this.rbmale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbmale.Location = new System.Drawing.Point(403, 393);
            this.rbmale.Margin = new System.Windows.Forms.Padding(1);
            this.rbmale.Name = "rbmale";
            this.rbmale.Size = new System.Drawing.Size(88, 29);
            this.rbmale.TabIndex = 19;
            this.rbmale.TabStop = true;
            this.rbmale.Text = "MALE";
            this.rbmale.UseVisualStyleBackColor = true;
            // 
            // cmbqualification
            // 
            this.cmbqualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbqualification.FormattingEnabled = true;
            this.cmbqualification.Items.AddRange(new object[] {
            "BA",
            "B.SC",
            "BCA",
            "B.COM",
            "B.TECH",
            "BBA",
            "MA",
            "M.SC",
            "MCA",
            "M.COM",
            "M.TECH",
            "MBA",
            "B.ED",
            "P.HD",
            "MBBS"});
            this.cmbqualification.Location = new System.Drawing.Point(277, 270);
            this.cmbqualification.Margin = new System.Windows.Forms.Padding(1);
            this.cmbqualification.Name = "cmbqualification";
            this.cmbqualification.Size = new System.Drawing.Size(271, 33);
            this.cmbqualification.TabIndex = 20;
            // 
            // cmbcity
            // 
            this.cmbcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcity.FormattingEnabled = true;
            this.cmbcity.Items.AddRange(new object[] {
            "PRAYAGRAJ",
            "VARANASI",
            "LUCKNOW",
            "KANPUR",
            "NOIDA",
            "AGRA",
            "MATHURA",
            "SYDNEY",
            "PERTH",
            "BIRMINGHOM",
            "MOSCOW",
            "NEWYORK"});
            this.cmbcity.Location = new System.Drawing.Point(277, 309);
            this.cmbcity.Margin = new System.Windows.Forms.Padding(1);
            this.cmbcity.Name = "cmbcity";
            this.cmbcity.Size = new System.Drawing.Size(271, 33);
            this.cmbcity.TabIndex = 21;
            // 
            // cmbcountry
            // 
            this.cmbcountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcountry.FormattingEnabled = true;
            this.cmbcountry.Items.AddRange(new object[] {
            "INDIA",
            "SRI-LANKA",
            "SOUTH AFRICA",
            "RUSSIA",
            "AUSTRAILIA",
            "ENGLAND",
            "USA",
            "SCOTLAND"});
            this.cmbcountry.Location = new System.Drawing.Point(277, 347);
            this.cmbcountry.Margin = new System.Windows.Forms.Padding(1);
            this.cmbcountry.Name = "cmbcountry";
            this.cmbcountry.Size = new System.Drawing.Size(271, 33);
            this.cmbcountry.TabIndex = 22;
            // 
            // cmbage
            // 
            this.cmbage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbage.FormattingEnabled = true;
            this.cmbage.Items.AddRange(new object[] {
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.cmbage.Location = new System.Drawing.Point(277, 512);
            this.cmbage.Margin = new System.Windows.Forms.Padding(1);
            this.cmbage.Name = "cmbage";
            this.cmbage.Size = new System.Drawing.Size(201, 33);
            this.cmbage.TabIndex = 23;
            // 
            // cmbms
            // 
            this.cmbms.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbms.FormattingEnabled = true;
            this.cmbms.Items.AddRange(new object[] {
            "UNMARRIED",
            "MARRIED",
            "DIVORCED",
            "OTHER"});
            this.cmbms.Location = new System.Drawing.Point(277, 549);
            this.cmbms.Margin = new System.Windows.Forms.Padding(1);
            this.cmbms.Name = "cmbms";
            this.cmbms.Size = new System.Drawing.Size(201, 33);
            this.cmbms.TabIndex = 24;
            // 
            // txtmail
            // 
            this.txtmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmail.Location = new System.Drawing.Point(277, 434);
            this.txtmail.Margin = new System.Windows.Forms.Padding(1);
            this.txtmail.Name = "txtmail";
            this.txtmail.Size = new System.Drawing.Size(271, 30);
            this.txtmail.TabIndex = 25;
            // 
            // txtmobile
            // 
            this.txtmobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.Location = new System.Drawing.Point(277, 471);
            this.txtmobile.Margin = new System.Windows.Forms.Padding(1);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(271, 30);
            this.txtmobile.TabIndex = 26;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(15, 551);
            this.label14.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(186, 25);
            this.label14.TabIndex = 27;
            this.label14.Text = "MARITAL STATUS";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(16, 590);
            this.label15.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(205, 25);
            this.label15.TabIndex = 28;
            this.label15.Text = "LANGUAGE KNOWN";
            // 
            // cbhindi
            // 
            this.cbhindi.AutoSize = true;
            this.cbhindi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbhindi.Location = new System.Drawing.Point(277, 590);
            this.cbhindi.Margin = new System.Windows.Forms.Padding(1);
            this.cbhindi.Name = "cbhindi";
            this.cbhindi.Size = new System.Drawing.Size(86, 29);
            this.cbhindi.TabIndex = 29;
            this.cbhindi.Text = "HINDI";
            this.cbhindi.UseVisualStyleBackColor = true;
            this.cbhindi.CheckedChanged += new System.EventHandler(this.cbhindi_CheckedChanged);
            // 
            // cbenglish
            // 
            this.cbenglish.AutoSize = true;
            this.cbenglish.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbenglish.Location = new System.Drawing.Point(387, 590);
            this.cbenglish.Margin = new System.Windows.Forms.Padding(1);
            this.cbenglish.Name = "cbenglish";
            this.cbenglish.Size = new System.Drawing.Size(120, 29);
            this.cbenglish.TabIndex = 30;
            this.cbenglish.Text = "ENGLISH";
            this.cbenglish.UseVisualStyleBackColor = true;
            this.cbenglish.CheckedChanged += new System.EventHandler(this.cbenglish_CheckedChanged);
            // 
            // insertbtn
            // 
            this.insertbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertbtn.ForeColor = System.Drawing.Color.Black;
            this.insertbtn.Location = new System.Drawing.Point(607, 491);
            this.insertbtn.Margin = new System.Windows.Forms.Padding(1);
            this.insertbtn.Name = "insertbtn";
            this.insertbtn.Size = new System.Drawing.Size(153, 31);
            this.insertbtn.TabIndex = 31;
            this.insertbtn.Text = "INSERT";
            this.insertbtn.UseVisualStyleBackColor = true;
            this.insertbtn.Click += new System.EventHandler(this.btnsubmit);
            // 
            // clearbtn
            // 
            this.clearbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbtn.ForeColor = System.Drawing.Color.Black;
            this.clearbtn.Location = new System.Drawing.Point(607, 548);
            this.clearbtn.Margin = new System.Windows.Forms.Padding(1);
            this.clearbtn.Name = "clearbtn";
            this.clearbtn.Size = new System.Drawing.Size(153, 31);
            this.clearbtn.TabIndex = 32;
            this.clearbtn.Text = "CLEAR";
            this.clearbtn.UseVisualStyleBackColor = true;
            this.clearbtn.Click += new System.EventHandler(this.clearbtn_Click);
            // 
            // dtpdob
            // 
            this.dtpdob.Location = new System.Drawing.Point(277, 197);
            this.dtpdob.Margin = new System.Windows.Forms.Padding(1);
            this.dtpdob.Name = "dtpdob";
            this.dtpdob.Size = new System.Drawing.Size(272, 22);
            this.dtpdob.TabIndex = 33;
            // 
            // rbother
            // 
            this.rbother.AutoSize = true;
            this.rbother.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbother.Location = new System.Drawing.Point(496, 390);
            this.rbother.Margin = new System.Windows.Forms.Padding(1);
            this.rbother.Name = "rbother";
            this.rbother.Size = new System.Drawing.Size(102, 29);
            this.rbother.TabIndex = 34;
            this.rbother.TabStop = true;
            this.rbother.Text = "OTHER";
            this.rbother.UseVisualStyleBackColor = true;
            // 
            // cburdu
            // 
            this.cburdu.AutoSize = true;
            this.cburdu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cburdu.Location = new System.Drawing.Point(523, 588);
            this.cburdu.Margin = new System.Windows.Forms.Padding(1);
            this.cburdu.Name = "cburdu";
            this.cburdu.Size = new System.Drawing.Size(89, 29);
            this.cburdu.TabIndex = 35;
            this.cburdu.Text = "URDU";
            this.cburdu.UseVisualStyleBackColor = true;
            this.cburdu.CheckedChanged += new System.EventHandler(this.cburdu_CheckedChanged);
            // 
            // updatebtn
            // 
            this.updatebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.ForeColor = System.Drawing.Color.Black;
            this.updatebtn.Location = new System.Drawing.Point(787, 491);
            this.updatebtn.Margin = new System.Windows.Forms.Padding(1);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(153, 31);
            this.updatebtn.TabIndex = 36;
            this.updatebtn.Text = "UPDATE";
            this.updatebtn.UseVisualStyleBackColor = true;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(956, 491);
            this.button4.Margin = new System.Windows.Forms.Padding(1);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(153, 31);
            this.button4.TabIndex = 37;
            this.button4.Text = "DELETE";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // viewbtn
            // 
            this.viewbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewbtn.ForeColor = System.Drawing.Color.Black;
            this.viewbtn.Location = new System.Drawing.Point(1136, 491);
            this.viewbtn.Margin = new System.Windows.Forms.Padding(1);
            this.viewbtn.Name = "viewbtn";
            this.viewbtn.Size = new System.Drawing.Size(153, 31);
            this.viewbtn.TabIndex = 38;
            this.viewbtn.Text = "VIEW";
            this.viewbtn.UseVisualStyleBackColor = true;
            this.viewbtn.Click += new System.EventHandler(this.viewbtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.Location = new System.Drawing.Point(607, 126);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(1);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowTemplate.Height = 46;
            this.dataGridView1.Size = new System.Drawing.Size(793, 331);
            this.dataGridView1.TabIndex = 39;
            this.dataGridView1.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseDoubleClick);
            // 
            // cmbid
            // 
            this.cmbid.DataSource = this.studentBindingSource1;
            this.cmbid.DisplayMember = "sid";
            this.cmbid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbid.FormattingEnabled = true;
            this.cmbid.Location = new System.Drawing.Point(841, 71);
            this.cmbid.Margin = new System.Windows.Forms.Padding(1);
            this.cmbid.Name = "cmbid";
            this.cmbid.Size = new System.Drawing.Size(201, 33);
            this.cmbid.TabIndex = 40;
            this.cmbid.ValueMember = "sid";
            this.cmbid.SelectedIndexChanged += new System.EventHandler(this.cmbid_SelectedIndexChanged);
            // 
            // studentBindingSource1
            // 
            this.studentBindingSource1.DataMember = "student";
            this.studentBindingSource1.DataSource = this.eMPDataSet1;
            // 
            // eMPDataSet1
            // 
            this.eMPDataSet1.DataSetName = "EMPDataSet1";
            this.eMPDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "student";
            this.studentBindingSource.DataSource = this.eMPDataSet;
            // 
            // eMPDataSet
            // 
            this.eMPDataSet.DataSetName = "EMPDataSet";
            this.eMPDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(607, 75);
            this.label16.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(176, 25);
            this.label16.TabIndex = 41;
            this.label16.Text = "SELECT YOUR ID";
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // studentTableAdapter1
            // 
            this.studentTableAdapter1.ClearBeforeFill = true;
            // 
            // ferrorProvider
            // 
            this.ferrorProvider.ContainerControl = this;
            // 
            // deletetbtn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1424, 660);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.cmbid);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.viewbtn);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.cburdu);
            this.Controls.Add(this.rbother);
            this.Controls.Add(this.dtpdob);
            this.Controls.Add(this.clearbtn);
            this.Controls.Add(this.insertbtn);
            this.Controls.Add(this.cbenglish);
            this.Controls.Add(this.cbhindi);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtmobile);
            this.Controls.Add(this.txtmail);
            this.Controls.Add(this.cmbms);
            this.Controls.Add(this.cmbage);
            this.Controls.Add(this.cmbcountry);
            this.Controls.Add(this.cmbcity);
            this.Controls.Add(this.cmbqualification);
            this.Controls.Add(this.rbmale);
            this.Controls.Add(this.rbfemale);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtmname);
            this.Controls.Add(this.txtfname);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "deletetbtn";
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.deletetbtn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eMPDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eMPDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ferrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.TextBox txtmname;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.RadioButton rbfemale;
        private System.Windows.Forms.RadioButton rbmale;
        private System.Windows.Forms.ComboBox cmbqualification;
        private System.Windows.Forms.ComboBox cmbcity;
        private System.Windows.Forms.ComboBox cmbcountry;
        private System.Windows.Forms.ComboBox cmbage;
        private System.Windows.Forms.ComboBox cmbms;
        private System.Windows.Forms.TextBox txtmail;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox cbhindi;
        private System.Windows.Forms.CheckBox cbenglish;
        private System.Windows.Forms.Button insertbtn;
        private System.Windows.Forms.Button clearbtn;
        private System.Windows.Forms.DateTimePicker dtpdob;
        private System.Windows.Forms.RadioButton rbother;
        private System.Windows.Forms.CheckBox cburdu;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button viewbtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cmbid;
        private System.Windows.Forms.Label label16;
        private EMPDataSet eMPDataSet;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private EMPDataSetTableAdapters.studentTableAdapter studentTableAdapter;
        private EMPDataSet1 eMPDataSet1;
        private System.Windows.Forms.BindingSource studentBindingSource1;
        private EMPDataSet1TableAdapters.studentTableAdapter studentTableAdapter1;
        private System.Windows.Forms.ErrorProvider ferrorProvider;
    }
}