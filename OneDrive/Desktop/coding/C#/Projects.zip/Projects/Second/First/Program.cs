﻿using System;
//System is a namespace which contain many classes like Console 
namespace First
{
    class Box          //Box is the name of class 
    {
        static void Main(string[] args)     //main method 
        {
            Console.Write("Rohan Kushwaha");  // 
            Console.ReadKey();
        }
    }
}
