﻿using System;


namespace AccessDemo1
{
    class Class1 : Program
    {
        static void Main(string [] args) {
            Class1 c = new Class1();
            c.Test2();
            c.Test3();
            c.Test4();
            c.Test5();
            Console.ReadKey();
        }
    }
}
