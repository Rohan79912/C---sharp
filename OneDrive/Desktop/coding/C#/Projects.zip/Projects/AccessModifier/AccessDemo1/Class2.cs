﻿using System;


namespace AccessDemo1
{
    class Class2
    {
        static void Main(String[] args)
        {
            Program p = new Program();
            p.Test3();
            p.Test2();
            p.Test5();
            Console.ReadKey();
        }
    }
}
